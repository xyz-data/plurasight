'use strict';

var toPrint = "print me";

function print(out){

  var stringToPrint = out;
  console.log(stringToPrint);
}

randomVariable = 23;
print('Hello');
//console.log(stringToPrint);
