'use strict';

var x = 120,
    y = 012;

console.log(x+y);