'use strict';
function x(a,b,a){
  console.log(a);

}

x(1,2,3);