var x = 1;

var y = '2';
if(x === y){
	console.log('Exist');
} else {
	console.log('Not Exist');
}

