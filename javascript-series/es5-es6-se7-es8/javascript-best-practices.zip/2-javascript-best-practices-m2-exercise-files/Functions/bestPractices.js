//variable first... 
var x = 10;
//functions next
function print(input){
  //variables first
  var x = 0 //this goes here... 
  //functions next
  function log(){
    //log stuff
  }
  //run code
  console.log(input);
}
//run code
print(10);
