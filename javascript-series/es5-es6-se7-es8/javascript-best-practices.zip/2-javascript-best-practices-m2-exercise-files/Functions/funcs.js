
expression();
myFunc();

var expression = function (){
  console.log('Hi from my expression');
}
function myFunc(){
  console.log('Hi from my func'); 
}
