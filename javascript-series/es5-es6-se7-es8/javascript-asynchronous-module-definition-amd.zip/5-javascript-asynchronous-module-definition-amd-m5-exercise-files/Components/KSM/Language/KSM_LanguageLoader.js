define(['KSM_Config', 'KSM_LanguageAMD'],function(config, language)
{	language.load(config.languageAbbr);	
});