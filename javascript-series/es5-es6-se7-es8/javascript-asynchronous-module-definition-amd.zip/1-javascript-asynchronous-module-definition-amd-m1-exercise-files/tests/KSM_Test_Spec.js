describe('The test', function()
{
	it('should work', function()
	{
		expect(2).toEqual(2);
	})
})