({
    baseUrl: './',
	mainConfigFile: 'Components/KSM_Start-33.js',
	findNestedDependencies: true,
	paths:
	{	'jquery': 'empty:',
		'jqx': 'empty:'
	},
	out: 'KSM_optimized.js',
	name: 'Components/KSM_Start-33'
})