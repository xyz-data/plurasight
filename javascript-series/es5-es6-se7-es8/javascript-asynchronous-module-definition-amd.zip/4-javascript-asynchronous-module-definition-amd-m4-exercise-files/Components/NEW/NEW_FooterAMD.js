/*  NEW_FooterAMD.js
*/
define(['jquery'], function($)
{	$('<p>')
		.addClass('footer')
		.html('New footer for sample web page for Pluralsight course')
			.insertAfter('.page');
});