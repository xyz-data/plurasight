define(
{   buttons: [],
	context: {},
	useToolbarHolder: true,
	height: '32px',
	autoAttach: true,
	scrollAreaClass: '.panel-body',
	toolbarButtonClass: '',
	toolbarButtonId: '',
	toolbarLineClass: '',
	toolbarLineId: '',
	toolbarHolderClass: '',
	toolbarHolderId: '',
	itemHeight: '34px',
	clearFloat: true
});