/*  KSM_FooterAMD.js
*/
require(['jquery'], function($)
{	$('<p>')
		.addClass('footer')
		.html('Sample web page for Pluralsight course')
		.insertAfter('.page');
});