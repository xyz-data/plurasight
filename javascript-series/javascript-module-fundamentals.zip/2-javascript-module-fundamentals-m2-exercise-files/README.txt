Node.js and npm are required to configure and run the MultiMath demo application.

They may be installed from the Node.js website (https://www.nodejs.org).

Before running the demo app from either the "Before" or "After" folders, you must install all of the required npm packages.

Install the npm packages and start the app with the following steps:
1. Open a terminal in the "MultiMath" folder.
2. Type "npm install".
3. Type "npm start".
4. Open a browser and visit http://localhost:8080.