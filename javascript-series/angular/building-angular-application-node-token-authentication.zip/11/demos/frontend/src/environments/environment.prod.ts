export const environment = {
  production: true,
  path: 'https://ps-social.herokuapp.com'  
};
