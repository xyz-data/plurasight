import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-blast',
  templateUrl: './email-blast.component.html',
  styleUrls: ['./email-blast.component.css']
})
export class EmailBlastComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
