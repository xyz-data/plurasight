## Watch Gulpfile.js only with Nodemon and rerun when updating
`nodemon --watch gulpfile.js --exec "gulp serve"`