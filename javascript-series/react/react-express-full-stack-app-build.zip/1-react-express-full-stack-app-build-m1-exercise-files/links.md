### All Lucky Sevens!
https://youtu.be/PcBKdM8R658?t=6m5s