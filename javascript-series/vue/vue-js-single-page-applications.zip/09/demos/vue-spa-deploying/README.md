[![Build Status](https://travis-ci.org/bstavroulakis/vue-spa.svg?branch=master)](https://travis-ci.org/bstavroulakis/vue-spa)
