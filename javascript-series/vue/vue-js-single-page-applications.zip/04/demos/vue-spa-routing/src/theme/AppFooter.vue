<template>
  <footer class="footer">
    <div class="container">
      <div class="content has-text-centered">
        Follow us on
        <a href="https://twitter.com/bstavroulakis" target="_blank">Twitter</a>
      </div>
    </div>
  </footer>
</template>
