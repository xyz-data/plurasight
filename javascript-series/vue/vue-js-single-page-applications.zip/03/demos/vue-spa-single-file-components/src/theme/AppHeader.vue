<template>
  <nav class="nav has-shadow">
    <div class="container">
      <a href="/">
        <img src="http://bit.ly/vue-img" alt="Vue SPA" />
      </a>
    </div>
  </nav>
</template>
