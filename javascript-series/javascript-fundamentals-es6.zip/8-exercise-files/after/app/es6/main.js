import {Company} from "./company";

let company = new Company();
company.hire("Joy", "Sue", "Tim", "Tom");
document.write(company.doWork());