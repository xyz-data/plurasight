"use strict";
var a = 5;
console.log(a);
