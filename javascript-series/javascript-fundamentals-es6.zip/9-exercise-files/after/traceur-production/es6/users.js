let a = 5;
console.log(a);