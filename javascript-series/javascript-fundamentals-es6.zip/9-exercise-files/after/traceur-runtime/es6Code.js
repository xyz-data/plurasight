let message = "in es6 code file";
console.log(message);