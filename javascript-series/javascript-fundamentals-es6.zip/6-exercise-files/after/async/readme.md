extract the contents of this zip
run "npm install" from the command line
run "bower install" from the command line
run "npm install grunt-cli -g" from the command line if you haven't already
run "grunt" from the command line
default.html should open in your default browser or you can browse to http://localhost:9000/default.html

when creating a new spec, be sure to add or edit the script tag in the default.html file