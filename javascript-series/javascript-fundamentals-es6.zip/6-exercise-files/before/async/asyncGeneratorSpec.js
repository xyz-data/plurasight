describe('async generators', function() {

});