describe('WeakSets', function() {
	
})