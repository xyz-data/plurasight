var express = require('express');

var hi = 'hello'


if (true) {
    console.log('hi');
}
console.log(hi);